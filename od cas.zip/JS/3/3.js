// var i= 0;
// do{
// 	console.log(i);
// 	i++;
// }
// while (i<10);

// for(var i=0; i<10;i++){
// 	console.log(i);
// }
// for (var i = 50; i > 0; i-=10) {
// 	console.log(i)
// }
// for(var i =0, j =0;i<5&&j<10;i++,j++){            da se izbegnuva
// 	console.log(i+" "+j);
// }

// var x=prompt("vensi use eden broj")
// var n = prompt("vnesi broj")
// var y=1;
// for(var i=1 ;i<=n;i++ ){
// 	y*=x
// 	console.log(y)
// }

// var n=prompt("vensi broj");
// var a=0;
// var b=0;
// var c=0;
// for (var i = 0; i <=n; i++) {
// 	if(i%3==0&&i%5==0){
// 		a++;
	
// 	}
// 	 else if(i%3==0){
// 		b++;
	
	
// 	}
// 	else if(i%5==0){
// 		c++;
// 	}
// }

// console.log(a);
// console.log(b);
// console.log(c);




for(var i =0;i<=10;i++){
	var square =i*i;
	if (square%2==0){
		continue;
//continue skoka se nadole DOKOLKU E TOCNO TOA SO SE PRESMETUVA!!!!! i samo se vrakja na toa gore
	}
	console.log(square);
}