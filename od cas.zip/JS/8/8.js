//staitments
// .filter e za filtriranje na neso so saas
// .map



// var niz =[100,3,4,9,6,7];
// for (var i=0;i<niz.length;i++){
// 	//niz[i]kako for of
// 	for(var j=i;j<niz.length;j++){
// 		if(niz[i]>niz[j]){
// 			var pom =niz[i];
// 			niz[i]=niz[j];
// 			niz[j]=pom;

// 		}
// 	}
// }
// var sum=(niz[niz.length-1]+niz[niz.length-2]);
// console.log(niz);
// console.log(sum);


// var niz =[1,19,29,99,49];
// for(var i=0;i<niz.length;i++){
// 	for(var j=i;niz.length;j++){
// 		if(niz[i]<niz[j]){
// 			var pom =niz[i];
// 			niz[i]=niz[j];
// 			niz[j]=pom;
// 		}
// 	}
// }
// console.log(niz);

// var niza =[1,2,3,4,5,6,7,8,9]
// const x =niza[0];
// for (let i of niza){
// console.log(niza[i])
	
// niza.push(x);

// }
// var niza= [1,2,3,4,5,6,7,8,9,9];
// var niza2 =niza.filter(x=>x%3==0);
// console.log(niza2);
var nizaobject = [{name:"ivan",surname:"petrevski",age:25},
{name:"ivan",surname:"petrevski",age:10},
{name:"ivan",surname:"petrevski",age:20},
{name:"ivan",surname:"petrevski",age:16}]
var niza2 =nizaobject.filter(x=>x.age>18);
console.log(niza2);