console.log(document.getElementById("title"));                               //za eden element da povikame od html
console.dir(document.getElementById("title"));
console.dir(document.getElementsByClassName("block")[0]);	
//za da zememem prviot ili vtoriot isto ko niza					//za edna ili povekje klasi da povikame od html
console.log(document.getElementsByTagName("a"))


document.getElementsByClassName("block")[0].innerText = "Zdravo";
document.getElementsByClassName("block")[1].innerHTML = `<h2>Ivan</h2>


<br>									
<p>da dsa dsa ds</p>

`;					//za povekje reda ako sakame da dodademe koristime `

document.getElementsByTagName("a")[0].attributes[0].value="https://www.google.com"; //za menjanje na atributi(value) na link
//mora da ima []za koj atribut e
document.getElementsByTagName("a")[0].setAttribute("href","https://www.youtube.com");
document.getElementsByTagName("a")[0].setAttribute("class","prvaklasa"); //za dodavanje atribut
document.getElementsByTagName("a")[0].classList.add("vtoraklasa");  //za dodavanje klasa
console.log(document.getElementsByTagName("a")[0].getAttribute("href")); //za da vidime atribut

document.write("semos");
document.title ="zdravo";
document.getElementsByClassName("block")[1].innerHTML =new Date();


// setTimeout(function(){
// 	alert("zdravo");
// },200000)

// var bomb =setInterval(function(){
// 	alert("ova e interval")
// },10000)

// function sayHI(who){
// 	alert("zdravo"+who);
// }																//funkcii za tajmer

// setTimeout(sayHI,2000,"ivan");

// setTimeout(function(){
// 	clearInterval(bomb);
// 	alert("bomb defused");
// },9000)

// var p = document.createElement("p");
// p.innerText = "vo semos uscite setTimeout";
// var title = document.getElementById("title");
// title.append(p);
// document.body.append(p);

document.getElementById("light_on").addEventListener("click",function(){
	document.getElementsByTagName("img")[0].setAttribute("src","https://www.w3schools.com/js/pic_bulbon.gif")
})
document.getElementById("light_off").addEventListener("click",function(){
	document.getElementsByTagName("img")[0].setAttribute("src","https://www.w3schools.com/js/pic_bulboff.gif")
})
var nizaobj = [{name:"ivan",surname:"petrevski",age:25},{name:"ivan",surname:"petrevski",age:25},{name:"ivan",surname:"petrevski",age:25}];



var table =document.createElement("table");
var tr=document.createElement("tr");
var firstObj =nizaobj[0];

for(var k in firstObj){
	var th =document.createElement("th");
	th.innerText=k;
	tr.append(th);
}
table.append(tr);
document.body.append(table);