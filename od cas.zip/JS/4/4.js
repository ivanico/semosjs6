//NIZI ARRAY




var niza = [1,2,3,"semos",4];  //pravenje niza
console.log(niza[3]);
console.log(niza.length);
var niza2 = new Array("a","b","c"); //dr nacin na pravenje niza
niza.push("cresi");   // se dodava element na kraj od nizata
console.log(niza);
niza.pop();        //go vadi posledniot element od nizata
console.log(niza);
var posleden =niza.pop();
console.log(posleden);
var prv =niza.shift(); // go vadi prviot element a so var mozeme da go zacuvame
console.log(niza);
console.log(prv);
niza.unshift("ananas"); //dodava element od npred
console.log(niza);
console.log(niza.join("-"));
niza.push("lubenica","jagodi",4,"jojo");
console.log(niza);
var sliced =niza.slice(1,4); // za da iskopiras elemnetite od 1 do 4 bez 4
console.log(sliced);
console.log(niza);
var n = niza.splice(2,2); //so prvata brojka oznacuvam kaj kje zastane i od tamu na desno so vtorata brojka brise ili gi kopira
console.log(n);
niza.splice(1,0,"sliva",0); //vaka moze i da se dodade poradi toa so e vtoriot broj 0
console.log(niza);
var c=niza.concat(niza2); // za spojuvanje na nizi so toa so gi dodava na kraj na prvata
for (var i =0;i<niza.length;i++){
	console.log(niza[i]);				//za da ni gi isprinta site elementi od nizata eden po eden pocnuvajki od prviot

}

for (i =niza.length-1;i>0;i--){
	console.log(niza[i]);				//za da gi pecati od pozadi eden po eden
}
niza[0]=5 // da smenime pozicija u niza

// OBJEKTI   OBJECT

var obj={name:"ivan",surname:"petrevski",age:25} //prv nacin na praenje object
console.log(obj.name);                    // name i surname se key za ivan i petrevski kako [0] vo niza  
console.log(obj["age"]);                 //dr nacina na pecatenje
obj.profession="NISTO";                   // za dodavanje pozadi
delete obj.age;                            //se brise
console.log("jas sum "+obj.name+" se prezivam "+ obj.surname+" imam " +obj.age+" god i rabotam "+obj.profession);
// se povikuva od objectot i so + se spojuva 
//dokolku se naprai obj = obj1 ne pravi kopija tuku se povrzuva i dokolku naprais promena vo edniot kje se napravi i vo vtoriot
var object={naslov:"akademija",glumci:["ivan" ,  "trajce" ,"draganco"],godina:2019}
obj.actors.push("d")