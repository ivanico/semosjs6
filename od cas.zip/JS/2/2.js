// var i =0;
// while (i<=10){
// 	console.log(i);
// 	i++;
// }
// var a=4;
// console.log(a);
// var b=a++;
// console.log(b);
// console.log(a);

// var j, i=0,k=7,m=5;
// console.log(i+" "+k" "+m);
// j=m+=2
 

 // var n = prompt("vnesi do koj broj kje sobiras");
 // var brojac=1;
 // var suma=0;

 // while(brojac<=n){
 // 	suma+=brojac;
 // 	brojac++;
 // }

 // console.log(suma);



 // var n = prompt("vnesi broj");

 // var brojce=0;

 // while (brojce<=n){
 // 	if (brojce%2==0) {
 // 		console.log(brojce)
 // 	}

 // 	brojce++;
 //  }

 //  brojce=0;
 //  while (brojce<=n){
 // 	if (brojce%2==1) {
 // 		console.log(brojce)
 // 	}

 // 	brojce++;
 //  }


// var n =prompt("vnesi broj");
// var brojac=1;
// var proizvod=1;
// while(brojac<=n){
// 	proizvod*=brojac;
// 	brojac++;
// }

// console.log(proizvod);



var n =prompt("vnesi broj");
var brojac=1;

while(brojac<=10){
	console.log(brojac*n);
		brojac++;

}