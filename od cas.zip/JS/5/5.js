var obj = {name :"WOW", year : 2017, actors :["a","b","c"]};
var arr = [1,2,3];
for (var k in obj){				
	console.log(k+" "+obj[k]);						//ovoj for se koristi za da doznaeme koj klucevi gi ima vo ovoj i dokolku saame da gi ispecati i objektite dodavame obj[k]
	if(Array.isArray(obj[k])){
		for (i of obj[k]){
			console.log(typeof i);					//typeof e za sto e toa dali e string ili broj ili slicno
			console.log(typeof obj.actors);
		}
	}	
}													//moze i so nizi da se koristi



for(var i of arr){
	console.log(i);									//za pecatenje na nizi,mapi,stringovi bez klucevite
}

var iv ="ivan";
for (var i of iv){									//primer za string kako bi go ispecatil
	console.log(i);
}

function pecati (){
	console.log("ivan");
	console.log("Semos");						//nema da ispecati niso sea se dodeka ne se povika funkcijata
	console.log("Zdravo");
}

pecati();										//se povikuva vaka!

function pecatiIme(name,surname){				// vo zagradata se zadavaat parametri
	console.log(name +" "+surname);				//zadavame so se pecati
}

pecatiIme("ivan","petrevski");					//so sakame da se ispecati
pecatiIme("stefan","petkovski");

function zdravo(a,b){
	console.log("zdravo "+a+" kako si "+b);
}

zdravo("ivan","denes");

function zbir (c,d){
	console.log(c+d);
	return c+d;										//ne pecati ali presmetuva
}

zbir(1,110);
function faktoriel(br1){
	var pr = 1;
	for(i=1;i<=br1;i++)
		pr*=i;

	console.log(pr);
		
}
faktoriel(120);


var a= function(num){
	console.log(num*2);
}
a(2);

var duble =(n)=>{ return n*2};			
console.log(duble(3));

var d =a=>a*2;
console.log(d(5));

var animal =(type,name)=>({tip:type,ime:name});
console.log(animal("dog","sarko"));						//=> fat arrow e ubrzana verzija od pravenje na nesto so sakame da napraime
//=> se koristi za praenje funkcia

var niza =[1,2,3,4];
var niza2 =niza.map(x=>x*2); 				//mapiranje efunkcija sto koristi edna niza da da naprai nekoja funkcija za da naprai nova niza so zadadenata funkcija
console.log(niza2);

function hi(){
	alert("Zdravo");
}

function bye(){
	alert("chao");							//call back funkcija

}

function greeting(a){
	a()
}
greeting(hi);



function z(){
	alert("zavrsiv domasna");
}
function pisuvaj(funkcija){
	alert("pisuvam domasna");
	funkcija();
}
pisuvaj(z);